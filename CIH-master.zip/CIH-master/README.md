# CIH
This is a copy of the original CIH virus but it has comments all through out explaining each piece of assembly code
